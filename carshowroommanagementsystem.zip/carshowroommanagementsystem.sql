-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2025 at 03:53 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carshowroommanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `car_id` int(11) NOT NULL,
  `car_number` varchar(20) DEFAULT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `year` int(20) DEFAULT NULL,
  `Transmission` varchar(255) NOT NULL,
  `fuel_type` varchar(50) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `seating_capacity` int(30) DEFAULT NULL,
  `price` int(40) DEFAULT NULL,
  `discount` int(40) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `features` text DEFAULT NULL,
  `added_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`car_id`, `car_number`, `brand`, `model`, `year`, `Transmission`, `fuel_type`, `color`, `seating_capacity`, `price`, `discount`, `status`, `features`, `added_date`) VALUES
(1, 'ABC123', 'Toyota', 'Corolla', 2020, 'Automatic', 'Petrol', 'White', 5, 2500000, 5, 'Available', 'Airbags, ABS, Sunroof', '2025-02-26 19:00:00'),
(2, 'XYZ456', 'Honda', 'Civic', 2021, 'Manual', 'Diesel', 'Black', 5, 3000000, 10, 'Available', 'Navigation, Sunroof, Leather Seats', '2025-02-26 19:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `customerstable`
--

CREATE TABLE `customerstable` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `Phone_number` varchar(255) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Gender` varchar(70) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `Cnic` varchar(20) DEFAULT NULL,
  `car_id` int(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customerstable`
--

INSERT INTO `customerstable` (`user_id`, `name`, `Phone_number`, `Email`, `Gender`, `Address`, `Cnic`, `car_id`) VALUES
(1, 'Hussain', '03331234567', 'abc@gmail.com', 'Male', 'Abc Colony', '4130412345678', 2);

-- --------------------------------------------------------

--
-- Table structure for table `logintable`
--

CREATE TABLE `logintable` (
  `Id` int(11) NOT NULL,
  `Name` varchar(70) DEFAULT NULL,
  `Email` varchar(70) DEFAULT NULL,
  `Password` varchar(70) DEFAULT NULL,
  `Security_Question` varchar(70) DEFAULT NULL,
  `Security_Answer` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logintable`
--

INSERT INTO `logintable` (`Id`, `Name`, `Email`, `Password`, `Security_Question`, `Security_Answer`) VALUES
(1, 'Urooj', 'urooj@gmail.com', 'pass123', 'fav color', 'xyz'),
(3, 'admin', 'admin@admin.com', 'abcd', 'Your Favorite Car', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `car_id` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `user_id`, `car_id`, `amount`, `payment_method`, `transaction_date`) VALUES
(1, 1, 2, 25000, 'Cash', '2025-02-26 19:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `rentalstable`
--

CREATE TABLE `rentalstable` (
  `rental_id` int(11) NOT NULL,
  `car_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `rental_start_date` date DEFAULT NULL,
  `total_rent` int(200) DEFAULT NULL,
  `monthly_installment` int(200) DEFAULT NULL,
  `installments_paid` int(200) DEFAULT NULL,
  `remaining_installments` int(200) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rentalstable`
--

INSERT INTO `rentalstable` (`rental_id`, `car_id`, `user_id`, `rental_start_date`, `total_rent`, `monthly_installment`, `installments_paid`, `remaining_installments`, `status`) VALUES
(1, 2, 1, '2025-02-01', 600000, 50000, 2, 10, 'Active'),
(2, 1, 2, '2025-02-25', 720000, 60000, 0, 12, 'Pending');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`car_id`),
  ADD UNIQUE KEY `car_number` (`car_number`);

--
-- Indexes for table `customerstable`
--
ALTER TABLE `customerstable`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `Phone_number` (`Phone_number`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `Cnic` (`Cnic`);

--
-- Indexes for table `logintable`
--
ALTER TABLE `logintable`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `rentalstable`
--
ALTER TABLE `rentalstable`
  ADD PRIMARY KEY (`rental_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customerstable`
--
ALTER TABLE `customerstable`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `logintable`
--
ALTER TABLE `logintable`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rentalstable`
--
ALTER TABLE `rentalstable`
  MODIFY `rental_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
